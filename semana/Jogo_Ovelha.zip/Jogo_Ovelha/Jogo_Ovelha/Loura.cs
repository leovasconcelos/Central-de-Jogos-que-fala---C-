﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace game
{
    class Loura
    {
        public int x, y;
        public Loura()
        {
            x = 0;
            y = 0;
        }
    }
}
