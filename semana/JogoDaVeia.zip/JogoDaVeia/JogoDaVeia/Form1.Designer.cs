﻿namespace JogoDaVeia
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.p1 = new System.Windows.Forms.PictureBox();
            this.p2 = new System.Windows.Forms.PictureBox();
            this.p3 = new System.Windows.Forms.PictureBox();
            this.p6 = new System.Windows.Forms.PictureBox();
            this.p5 = new System.Windows.Forms.PictureBox();
            this.p4 = new System.Windows.Forms.PictureBox();
            this.p9 = new System.Windows.Forms.PictureBox();
            this.p8 = new System.Windows.Forms.PictureBox();
            this.p7 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.p10 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.p1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.p10)).BeginInit();
            this.SuspendLayout();
            // 
            // p1
            // 
            this.p1.BackColor = System.Drawing.Color.Blue;
            this.p1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p1.Location = new System.Drawing.Point(22, 104);
            this.p1.Name = "p1";
            this.p1.Size = new System.Drawing.Size(65, 65);
            this.p1.TabIndex = 0;
            this.p1.TabStop = false;
            this.p1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // p2
            // 
            this.p2.BackColor = System.Drawing.Color.Blue;
            this.p2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p2.Location = new System.Drawing.Point(108, 104);
            this.p2.Name = "p2";
            this.p2.Size = new System.Drawing.Size(65, 65);
            this.p2.TabIndex = 1;
            this.p2.TabStop = false;
            this.p2.Click += new System.EventHandler(this.p2_Click);
            // 
            // p3
            // 
            this.p3.BackColor = System.Drawing.Color.Blue;
            this.p3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p3.Location = new System.Drawing.Point(194, 104);
            this.p3.Name = "p3";
            this.p3.Size = new System.Drawing.Size(65, 65);
            this.p3.TabIndex = 2;
            this.p3.TabStop = false;
            this.p3.Click += new System.EventHandler(this.p3_Click);
            // 
            // p6
            // 
            this.p6.BackColor = System.Drawing.Color.Blue;
            this.p6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p6.Location = new System.Drawing.Point(194, 190);
            this.p6.Name = "p6";
            this.p6.Size = new System.Drawing.Size(65, 65);
            this.p6.TabIndex = 5;
            this.p6.TabStop = false;
            this.p6.Click += new System.EventHandler(this.p6_Click);
            // 
            // p5
            // 
            this.p5.BackColor = System.Drawing.Color.Blue;
            this.p5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p5.Location = new System.Drawing.Point(108, 190);
            this.p5.Name = "p5";
            this.p5.Size = new System.Drawing.Size(65, 65);
            this.p5.TabIndex = 4;
            this.p5.TabStop = false;
            this.p5.Click += new System.EventHandler(this.p5_Click);
            // 
            // p4
            // 
            this.p4.BackColor = System.Drawing.Color.Blue;
            this.p4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p4.Location = new System.Drawing.Point(22, 190);
            this.p4.Name = "p4";
            this.p4.Size = new System.Drawing.Size(65, 65);
            this.p4.TabIndex = 3;
            this.p4.TabStop = false;
            this.p4.Click += new System.EventHandler(this.p4_Click);
            // 
            // p9
            // 
            this.p9.BackColor = System.Drawing.Color.Blue;
            this.p9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p9.Location = new System.Drawing.Point(194, 276);
            this.p9.Name = "p9";
            this.p9.Size = new System.Drawing.Size(65, 65);
            this.p9.TabIndex = 8;
            this.p9.TabStop = false;
            this.p9.Click += new System.EventHandler(this.p9_Click);
            // 
            // p8
            // 
            this.p8.BackColor = System.Drawing.Color.Blue;
            this.p8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p8.Location = new System.Drawing.Point(108, 276);
            this.p8.Name = "p8";
            this.p8.Size = new System.Drawing.Size(65, 65);
            this.p8.TabIndex = 7;
            this.p8.TabStop = false;
            this.p8.Click += new System.EventHandler(this.p8_Click);
            // 
            // p7
            // 
            this.p7.BackColor = System.Drawing.Color.Blue;
            this.p7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.p7.Location = new System.Drawing.Point(22, 276);
            this.p7.Name = "p7";
            this.p7.Size = new System.Drawing.Size(65, 65);
            this.p7.TabIndex = 6;
            this.p7.TabStop = false;
            this.p7.Click += new System.EventHandler(this.p7_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(224, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "label1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 46);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "label3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(224, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "label4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(19, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "label5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(224, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "label6";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(33, 363);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Resetar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // p10
            // 
            this.p10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.p10.Location = new System.Drawing.Point(218, 12);
            this.p10.Name = "p10";
            this.p10.Size = new System.Drawing.Size(41, 31);
            this.p10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.p10.TabIndex = 15;
            this.p10.TabStop = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(139, 364);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 23);
            this.button2.TabIndex = 16;
            this.button2.Text = "Restart";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(282, 399);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.p10);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.p9);
            this.Controls.Add(this.p8);
            this.Controls.Add(this.p7);
            this.Controls.Add(this.p6);
            this.Controls.Add(this.p5);
            this.Controls.Add(this.p4);
            this.Controls.Add(this.p3);
            this.Controls.Add(this.p2);
            this.Controls.Add(this.p1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.p1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.p10)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox p1;
        private System.Windows.Forms.PictureBox p2;
        private System.Windows.Forms.PictureBox p3;
        private System.Windows.Forms.PictureBox p6;
        private System.Windows.Forms.PictureBox p5;
        private System.Windows.Forms.PictureBox p4;
        private System.Windows.Forms.PictureBox p9;
        private System.Windows.Forms.PictureBox p8;
        private System.Windows.Forms.PictureBox p7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox p10;
        private System.Windows.Forms.Button button2;
    }
}

